﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class addComplain : Form
    {
        private int localUser;

        public addComplain(int userId)
        {
            InitializeComponent();
            localUser = userId;
            LoadPastComplaints();
            CustomizeDataGridView();
        }

        private void addComplain_Load(object sender, EventArgs e)
        {
        }

        private void LoadPastComplaints()
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();

                // Fetch past complaints for the current user
                OracleCommand getPastComplaints = con.CreateCommand();
                getPastComplaints.CommandText = @"SELECT SupportTicketID, IssueDescription, DateSubmitted, ResolutionStatus
                                                  FROM CustomerSupport
                                                  WHERE SubmittedByUserID = :userId";
                getPastComplaints.CommandType = CommandType.Text;
                getPastComplaints.Parameters.Add(":userId", OracleDbType.Int32).Value = localUser;

                // Load data into the DataGridView
                using (OracleDataReader reader = getPastComplaints.ExecuteReader())
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    complaintsDataGridView.DataSource = dt;
                }
                con.Close();
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            // Insert new complaint into the database
            string issueDescription = richTextBox.Text;

            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();

                // Insert the new complaint
                OracleCommand insertComplaint = con.CreateCommand();
                insertComplaint.CommandText = @"INSERT INTO CustomerSupport (SubmittedByUserID, IssueDescription, DateSubmitted, ResolutionStatus)
                                                VALUES (:userId, :issueDescription, SYSDATE, 'Open')";
                insertComplaint.CommandType = CommandType.Text;
                insertComplaint.Parameters.Add(":userId", OracleDbType.Int32).Value = localUser;
                insertComplaint.Parameters.Add(":issueDescription", OracleDbType.Varchar2).Value = issueDescription;

                // Execute the command
                int rowsInserted = insertComplaint.ExecuteNonQuery();

                // Check if the insertion was successful
                if (rowsInserted > 0)
                {
                    MessageBox.Show("Complaint submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Reload past complaints
                    LoadPastComplaints();
                }
                else
                {
                    MessageBox.Show("Failed to submit complaint.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                // Close the connection
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Patient patientForm = new Patient(localUser);
            patientForm.Closed += (s, args) => this.Close();
            patientForm.Show();
        }

        private void CustomizeDataGridView()
        {
            // Set the font for readability
            complaintsDataGridView.DefaultCellStyle.Font = new Font("Segoe UI", 8);
            complaintsDataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 7);

            // Purple and white color scheme
            complaintsDataGridView.BackgroundColor = Color.White;
            complaintsDataGridView.GridColor = Color.Lavender;
            complaintsDataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.MediumPurple;
            complaintsDataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set the RowHeaders to be invisible if not needed
            complaintsDataGridView.RowHeadersVisible = false;

            // Set grid lines for better separation of data
            complaintsDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            complaintsDataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;

            // Adjust row height
            complaintsDataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            complaintsDataGridView.RowTemplate.Height = 30; // Set this to a suitable height

            // Highlight the selected row
            complaintsDataGridView.DefaultCellStyle.SelectionBackColor = Color.DarkOrchid; // A professional purple color
            complaintsDataGridView.DefaultCellStyle.SelectionForeColor = Color.White;

            // Use alternating row style
            complaintsDataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.LavenderBlush; // A light purple tint
            complaintsDataGridView.AlternatingRowsDefaultCellStyle.ForeColor = Color.Black;

            // Auto-Size columns based on content
            complaintsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Make the grid read-only if you don't want users to edit it directly
            complaintsDataGridView.ReadOnly = true;

            // Enable row headers to select rows if needed
            complaintsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Reduce padding for a cleaner look
            complaintsDataGridView.DefaultCellStyle.Padding = new Padding(5);

            // Set the height for column headers
            complaintsDataGridView.ColumnHeadersHeight = 35;

            // Set wrap mode for text
            complaintsDataGridView.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            // Improve the look of the header cells
            complaintsDataGridView.EnableHeadersVisualStyles = false;
            complaintsDataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set the default cell style alignment
            complaintsDataGridView.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            // Set the border style for a flat look
            complaintsDataGridView.BorderStyle = BorderStyle.None;

            // Remove the last blank row
            complaintsDataGridView.AllowUserToAddRows = false;
        }

    }
}
