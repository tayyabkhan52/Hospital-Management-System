﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class appointmentHistory : Form
    {
        private int PatId;
        private int UserId;

        public appointmentHistory(int patId, int userId)
        {
            InitializeComponent();
            PatId = patId;
            UserId = userId;
           
            LoadAppointmentHistory();
            CustomizeDataGridView();
            appointmentsDataGridView.SelectionChanged += appointmentsDataGridView_SelectionChanged;
        }

        private void appointmentHistory_Load(object sender, EventArgs e)
        {
       
            LoadAppointmentHistory();
        }

        private void LoadAppointmentHistory()
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();

                // Fetch appointment history for the current patient
                OracleCommand getAppointmentHistory = con.CreateCommand();
                getAppointmentHistory.CommandText = @"SELECT A.AppointmentID,
                                                      TO_CHAR(A.ScheduledTime, 'DD-MON-YY HH12:MI:SS AM') AS ScheduledTime,
                                                      TO_CHAR(A.EndTime, 'DD-MON-YY HH12:MI:SS AM') AS EndTime,
                                                      A.Purpose,
                                                      A.Status,
                                                      E.EmployeeID,
                                                      P.FirstName || ' ' || P.LastName AS DoctorName
                                               FROM Appointments A
                                               INNER JOIN Employees E ON A.EmployeeID = E.EmployeeID
                                               INNER JOIN Profiles P ON E.ProfileID = P.ProfileID
                                               WHERE A.PatientID = :patientId";
                getAppointmentHistory.CommandType = CommandType.Text;
                getAppointmentHistory.Parameters.Add(":patientId", OracleDbType.Int32).Value = PatId;

                // Load data into the DataGridView
                using (OracleDataReader reader = getAppointmentHistory.ExecuteReader())
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    appointmentsDataGridView.DataSource = dt;
                }

                // Close the connection
                con.Close();
            }
        }


        private void appointmentsDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            // Update labels with appointment details when a row is selected
            if (appointmentsDataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = appointmentsDataGridView.SelectedRows[0];
                appointmentIDLabel.Text = selectedRow.Cells["AppointmentID"].Value.ToString();
                purposeLabel.Text = selectedRow.Cells["Purpose"].Value.ToString();
                statusLabel.Text = selectedRow.Cells["Status"].Value.ToString();
                DoctornameLabel.Text = selectedRow.Cells["DoctorName"].Value.ToString();
            }
        }

        private void CustomizeDataGridView()
        {
            // Set the font for readability
            appointmentsDataGridView.DefaultCellStyle.Font = new Font("Segoe UI", 8);
            appointmentsDataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 7);

            // Purple and white color scheme
            appointmentsDataGridView.BackgroundColor = Color.White;
            appointmentsDataGridView.GridColor = Color.Lavender;
            appointmentsDataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.MediumPurple;
            appointmentsDataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set the RowHeaders to be invisible if not needed
            appointmentsDataGridView.RowHeadersVisible = false;

            // Set grid lines for better separation of data
            appointmentsDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            appointmentsDataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;

            // Adjust row height
            appointmentsDataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            appointmentsDataGridView.RowTemplate.Height = 30; // Set this to a suitable height

            // Highlight the selected row
            appointmentsDataGridView.DefaultCellStyle.SelectionBackColor = Color.DarkOrchid; // A professional purple color
            appointmentsDataGridView.DefaultCellStyle.SelectionForeColor = Color.White;

            // Use alternating row style
                appointmentsDataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.LavenderBlush; // A light purple tint
            appointmentsDataGridView.AlternatingRowsDefaultCellStyle.ForeColor = Color.Black;

            // Auto-Size columns based on content
            appointmentsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Make the grid read-only if you don't want users to edit it directly
            appointmentsDataGridView.ReadOnly = true;

            // Enable row headers to select rows if needed
            appointmentsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Reduce padding for a cleaner look
            appointmentsDataGridView.DefaultCellStyle.Padding = new Padding(5);

            // Set the height for column headers
            appointmentsDataGridView.ColumnHeadersHeight = 35;

            // Set wrap mode for text
            appointmentsDataGridView.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            // Improve the look of the header cells
            appointmentsDataGridView.EnableHeadersVisualStyles = false;
            appointmentsDataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set the default cell style alignment
            appointmentsDataGridView.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            // Set the border style for a flat look
            appointmentsDataGridView.BorderStyle = BorderStyle.None;

            // Remove the last blank row
            appointmentsDataGridView.AllowUserToAddRows = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //close this form upon opening the patient form with the same userId
            this.Hide();
            Patient patientForm = new Patient(UserId);
            patientForm.Closed += (s, args) => this.Close();
            patientForm.Show();
        }
    }
}
