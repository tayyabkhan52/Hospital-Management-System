﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
   
    public partial class ManageEmployee : Form
    {
        int loggedInUserId; 
        public ManageEmployee(int a)
        {
            loggedInUserId = a;
            InitializeComponent();
            LoadData();
            LoadDepartments();
            EmployeesGrid.SelectionChanged += EmployeesGrid_SelectionChanged;
            CustomizeDataGridView();
            LoadRoles();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void LoadData()
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();
                OracleDataAdapter adapter = new OracleDataAdapter("SELECT * FROM Employees", con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                EmployeesGrid.DataSource = dt;
                con.Close();
            }
        }

        private void EmployeesGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (EmployeesGrid.SelectedRows.Count > 0)
            {
                int selectedRowIndex = EmployeesGrid.SelectedRows[0].Index;
                if (selectedRowIndex >= 0)
                {
                    DataGridViewRow row = EmployeesGrid.Rows[selectedRowIndex];
                    int profileID = Convert.ToInt32(row.Cells["ProfileID"].Value);
                    LoadProfileData(profileID);
                    string employeeID;
                    int deptID;
                    //extract the id of the selected employee and update the empId label
                    employeeID = row.Cells["EmployeeID"].Value.ToString();
                    EmpId.Text = employeeID;
                    //extract the department id of the selected employee and update the deptId combobox with the department name it should also show all other departments as well upon expansion
                    // Update the Departments ComboBox to reflect the selected employee's department
                    deptID = Convert.ToInt32(row.Cells["DepartmentID"].Value);
                    Departments.SelectedValue = deptID;
                    //extract the hiring date now into dateTimePicker1
                    if (DateTime.TryParseExact(row.Cells["HireDate"].Value.ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime hiringDate))
                    {
                        dateTimePicker1.Value = hiringDate.Date; // Extracting only the date part
                    }
                   
                    string position = row.Cells["Position"].Value.ToString();
                    employeePosition.Text = position;
                
                    string salary = row.Cells["Salary"].Value.ToString();
                    employeeSalary.Text = salary;


                }
            }
        }
        private void LoadProfileData(int profileID)
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();
                OracleDataAdapter adapter = new OracleDataAdapter($"SELECT ProfileID, UserID, FirstName, LastName, Email, PhoneNumber, Address, DateOfBirth FROM Profiles WHERE ProfileID = {profileID}", con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ProfileGrid.DataSource = dt;
                //hide the profileId and employeeId columns
                ProfileGrid.Columns["ProfileID"].Visible = false;
                ProfileGrid.Columns["UserID"].Visible = false;

                //now we extract the data from the profile grid and update the textboxes
                if (ProfileGrid.Rows.Count > 0)
                {
                    DataGridViewRow row = ProfileGrid.Rows[0];
                    string firstName = row.Cells["FirstName"].Value.ToString();
                    string lastName = row.Cells["LastName"].Value.ToString();
                    string email = row.Cells["Email"].Value.ToString();
                    string phoneNumber = row.Cells["PhoneNumber"].Value.ToString();
                    string address = row.Cells["Address"].Value.ToString();
                    string dateOfBirth = row.Cells["DateOfBirth"].Value.ToString();
                    //find the username and passsword from USERS table of the associated employee from the userID
                    OracleCommand selectCmd = con.CreateCommand();
                    selectCmd.CommandText = $"SELECT Username, Password FROM USERS WHERE UserID = {row.Cells["UserID"].Value}";
                    selectCmd.CommandType = CommandType.Text;
                    OracleDataReader reader = selectCmd.ExecuteReader();
                    if (reader.Read())
                    {
                        string username = reader.GetString(0);
                        string password = reader.GetString(1);
                        // Update the textboxes with the extracted data
                        Username.Text = username;
                        UserPassword.Text = password;
                    }

                    // Update the textboxes with the extracted data
                    FirstName.Text = firstName;
                    LastName.Text = lastName;
                    Email.Text = email;
                    PhoneNumber.Text = phoneNumber;
                    Address.Text = address;
                    //extract only the date part of the date of birth
                    if (DateTime.TryParseExact(dateOfBirth, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dob))
                    {
                        DateofBirth.Value = dob.Date; // Extracting only the date part
                    }
                    //update the role combobox with the role of the selected employee
                    OracleCommand selectRoleCmd = con.CreateCommand();
                    selectRoleCmd.CommandText = $"SELECT RoleID FROM USERS WHERE UserID = {row.Cells["UserID"].Value}";
                    selectRoleCmd.CommandType = CommandType.Text;
                    Role.SelectedValue = Convert.ToInt32(selectRoleCmd.ExecuteScalar());

                }

                con.Close();


            }
        }


        private void LoadDepartments()
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();
                OracleDataAdapter adapter = new OracleDataAdapter("SELECT DepartmentID, DepartmentName FROM Departments ORDER BY DepartmentName", con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Set up the ComboBox
                Departments.DisplayMember = "DepartmentName";
                Departments.ValueMember = "DepartmentID";
                Departments.DataSource = dt;

                con.Close();
            }
        }




        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin adminForm = new Admin(loggedInUserId);
            adminForm.Closed += (s, args) => this.Close();
            adminForm.Show();

        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();
                OracleCommand insertCommand = con.CreateCommand();

                insertCommand.CommandText = @"
        DECLARE
            v_UserID NUMBER;
            v_ProfileID NUMBER;
        BEGIN
            -- Insert into Users table to generate UserID
             INSERT INTO Users (UserID, Username, Password, RoleID)
            VALUES (USER_ID_SEQ.NEXTVAL, :p_Username, :p_Password, :p_RoleID) 
            RETURNING UserID INTO v_UserID;

            -- Insert into Profiles table using the generated UserID
             INSERT INTO Profiles (ProfileID, UserID, FirstName, LastName, Email, PhoneNumber, Address, DateOfBirth)
            VALUES (PROFILE_ID_SEQ.NEXTVAL, v_UserID, :p_FirstName, :p_LastName, :p_Email, :p_PhoneNumber, :p_Address, :p_DateOfBirth) 
            RETURNING ProfileID INTO v_ProfileID;

            -- Insert into Employees table using the generated ProfileID
            INSERT INTO Employees (EmployeeID, ProfileID, DepartmentID, HireDate, Position, Salary)
            VALUES (EMPLOYEE_ID_SEQ.NEXTVAL,v_ProfileID, :p_DepartmentID, :p_HireDate, :p_Position, :p_Salary);
            
            COMMIT;
        END;";

                
                insertCommand.Parameters.Add("p_Username", OracleDbType.Varchar2).Value = Username.Text; 
                insertCommand.Parameters.Add("p_Password", OracleDbType.Varchar2).Value = UserPassword.Text;
                insertCommand.Parameters.Add("p_RoleID", OracleDbType.Int32).Value = Convert.ToInt32(Role.SelectedValue);
                insertCommand.Parameters.Add("p_FirstName", OracleDbType.Varchar2).Value = FirstName.Text; 
                insertCommand.Parameters.Add("p_LastName", OracleDbType.Varchar2).Value = LastName.Text; 
                insertCommand.Parameters.Add("p_Email", OracleDbType.Varchar2).Value = Email.Text; 
                insertCommand.Parameters.Add("p_PhoneNumber", OracleDbType.Varchar2).Value = PhoneNumber.Text; // PhoneNumber TextBox
                insertCommand.Parameters.Add("p_Address", OracleDbType.Varchar2).Value = Address.Text; // Address TextBox
                insertCommand.Parameters.Add("p_DateOfBirth", OracleDbType.Date).Value = DateofBirth.Value; // DateOfBirth DateTimePicker
                insertCommand.Parameters.Add("p_DepartmentID", OracleDbType.Int32).Value = Convert.ToInt32(Departments.SelectedValue); // Departments 
                insertCommand.Parameters.Add("p_HireDate", OracleDbType.Date).Value = dateTimePicker1.Value; // HireDate DateTimePicker
                insertCommand.Parameters.Add("p_Position", OracleDbType.Varchar2).Value = employeePosition.Text; // Position TextBox
                insertCommand.Parameters.Add("p_Salary", OracleDbType.Decimal).Value = Convert.ToDecimal(employeeSalary.Text); // Salary TextBox

                try
                {
                    insertCommand.ExecuteNonQuery();
                    MessageBox.Show("New employee inserted successfully.");
                    LoadData(); // Refresh DataGridView
                }
                catch (OracleException ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            
            if (MessageBox.Show("Are you sure you want to delete this employee?", "Confirm Deletion", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (EmployeesGrid.SelectedRows.Count > 0)
                {
                    int selectedRowIndex = EmployeesGrid.SelectedRows[0].Index;
                    if (selectedRowIndex >= 0)
                    {
                        int employeeID = Convert.ToInt32(EmployeesGrid.Rows[selectedRowIndex].Cells["EmployeeID"].Value);
                        DeleteEmployee(employeeID);
                    }
                }
            }
        }

        private void DeleteEmployee(int employeeID)
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();
                OracleCommand cmd = new OracleCommand("DELETE_EMPLOYEE", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_EmployeeID", OracleDbType.Int32).Value = employeeID;

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Employee and associated records deleted successfully.");
                    LoadData(); // Refresh the DataGridView to reflect the changes
                }
                catch (OracleException ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            if (EmployeesGrid.SelectedRows.Count > 0)
            {
                int selectedRowIndex = EmployeesGrid.SelectedRows[0].Index;
                DataGridViewRow selectedRow = EmployeesGrid.Rows[selectedRowIndex];

                // Retrieve the current employee's ID, profile ID, and user ID
                int employeeID = Convert.ToInt32(selectedRow.Cells["EmployeeID"].Value);
                int profileID = Convert.ToInt32(selectedRow.Cells["ProfileID"].Value);
                int userID; // You'll need to fetch this from the database using the profileID

                using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
                {
                    con.Open();

                    // Fetch the userID from Profiles table using the profileID
                    OracleCommand getUserIdCmd = new OracleCommand("SELECT UserID FROM Profiles WHERE ProfileID = :profileId", con);
                    getUserIdCmd.Parameters.Add(new OracleParameter("profileId", profileID));
                    userID = Convert.ToInt32(getUserIdCmd.ExecuteScalar());

                    // Begin a transaction to ensure atomicity
                    OracleTransaction transaction = con.BeginTransaction();

                    try
                    {
                        // Update the Users table
                        OracleCommand updateUsersCmd = new OracleCommand("UPDATE Users SET Username = :username, Password = :password WHERE UserID = :userId", con);
                        updateUsersCmd.Parameters.Add(new OracleParameter("username", Username.Text));
                        updateUsersCmd.Parameters.Add(new OracleParameter("password", UserPassword.Text));
                        updateUsersCmd.Parameters.Add(new OracleParameter("userId", userID));
                        updateUsersCmd.ExecuteNonQuery();

                        // Update the Profiles table
                        OracleCommand updateProfilesCmd = new OracleCommand("UPDATE Profiles SET FirstName = :firstName, LastName = :lastName, Email = :email, PhoneNumber = :phoneNumber, Address = :address, DateOfBirth = :dateOfBirth WHERE ProfileID = :profileId", con);
                        updateProfilesCmd.Parameters.Add(new OracleParameter("firstName", FirstName.Text));
                        updateProfilesCmd.Parameters.Add(new OracleParameter("lastName", LastName.Text));
                        updateProfilesCmd.Parameters.Add(new OracleParameter("email", Email.Text));
                        updateProfilesCmd.Parameters.Add(new OracleParameter("phoneNumber", PhoneNumber.Text));
                        updateProfilesCmd.Parameters.Add(new OracleParameter("address", Address.Text));
                        updateProfilesCmd.Parameters.Add(new OracleParameter("dateOfBirth", DateofBirth.Value));
                        updateProfilesCmd.Parameters.Add(new OracleParameter("profileId", profileID));
                        updateProfilesCmd.ExecuteNonQuery();

                        // Update the Employees table
                        OracleCommand updateEmployeesCmd = new OracleCommand("UPDATE Employees SET DepartmentID = :departmentId, HireDate = :hireDate, Position = :position, Salary = :salary WHERE EmployeeID = :employeeId", con);
                        updateEmployeesCmd.Parameters.Add(new OracleParameter("departmentId", Convert.ToInt32(Departments.SelectedValue)));
                        updateEmployeesCmd.Parameters.Add(new OracleParameter("hireDate", dateTimePicker1.Value));
                        updateEmployeesCmd.Parameters.Add(new OracleParameter("position", employeePosition.Text));
                        updateEmployeesCmd.Parameters.Add(new OracleParameter("salary", Convert.ToDecimal(employeeSalary.Text)));
                        updateEmployeesCmd.Parameters.Add(new OracleParameter("employeeId", employeeID));
                        updateEmployeesCmd.ExecuteNonQuery();

                        // Commit the transaction
                        transaction.Commit();
                        MessageBox.Show("Employee updated successfully.");

                        // Refresh the DataGridView to show the updated data
                        LoadData();
                    }
                    catch (OracleException ex)
                    {
                        // Attempt to roll back the transaction
                        transaction.Rollback();
                        MessageBox.Show("An error occurred while updating the employee. " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("No employee selected for updating.");
            }
        }

        private void ManageEmployee_Load(object sender, EventArgs e)
        {

        }
        private void LoadRoles()
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();
                OracleDataAdapter adapter = new OracleDataAdapter("SELECT RoleID, RoleName FROM Roles ORDER BY RoleName", con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Set up the ComboBox
                Role.DisplayMember = "RoleName";
                Role.ValueMember = "RoleID";
                Role.DataSource = dt;

                con.Close();
            }
        }


        private void CustomizeDataGridView()
        {
            // Assuming 'EmployeesGrid' is your DataGridView
            // Set the font for readability
            EmployeesGrid.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            ProfileGrid.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            EmployeesGrid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 10);
            ProfileGrid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 10);

            // Purple and white color scheme
            EmployeesGrid.BackgroundColor = Color.White;
            EmployeesGrid.GridColor = Color.Lavender;
            EmployeesGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.MediumPurple;
            EmployeesGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            ProfileGrid.BackgroundColor = Color.White;
            ProfileGrid.GridColor = Color.Lavender;
            ProfileGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.MediumPurple;
            ProfileGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            

            // Set the RowHeaders to be invisible if not needed
            EmployeesGrid.RowHeadersVisible = false;
            ProfileGrid.RowHeadersVisible = false;
            // Set grid lines for better separation of data
            EmployeesGrid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            EmployeesGrid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;

            ProfileGrid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            ProfileGrid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;

            // Adjust row height
            EmployeesGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            EmployeesGrid.RowTemplate.Height = 30; // Set this to a suitable height

            ProfileGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            ProfileGrid.RowTemplate.Height = 30; // Set this to a suitable height

            // Highlight the selected row
            EmployeesGrid.DefaultCellStyle.SelectionBackColor = Color.DarkOrchid; // A professional purple color
            EmployeesGrid.DefaultCellStyle.SelectionForeColor = Color.White;

            ProfileGrid.DefaultCellStyle.SelectionBackColor = Color.DarkOrchid; // A professional purple color
            ProfileGrid.DefaultCellStyle.SelectionForeColor = Color.White;
            // Use alternating row style
            EmployeesGrid.AlternatingRowsDefaultCellStyle.BackColor = Color.LavenderBlush; // A light purple tint
            EmployeesGrid.AlternatingRowsDefaultCellStyle.ForeColor = Color.Black;

            ProfileGrid.AlternatingRowsDefaultCellStyle.BackColor = Color.LavenderBlush; // A light purple tint
            ProfileGrid.AlternatingRowsDefaultCellStyle.ForeColor = Color.Black;
            // Auto-Size columns based on content
            EmployeesGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            ProfileGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            // Make the grid read-only if you don't want users to edit it directly
            EmployeesGrid.ReadOnly = true;
            ProfileGrid.ReadOnly = true;

            // Enable row headers to select rows if needed
            EmployeesGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ProfileGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Reduce padding for a cleaner look
            EmployeesGrid.DefaultCellStyle.Padding = new Padding(5);
            ProfileGrid.DefaultCellStyle.Padding = new Padding(5);

            // Set the height for column headers
            EmployeesGrid.ColumnHeadersHeight = 35;
            ProfileGrid.ColumnHeadersHeight = 35;

            // Set wrap mode for text
            EmployeesGrid.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            ProfileGrid.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            // Improve the look of the header cells
            EmployeesGrid.EnableHeadersVisualStyles = false;
            EmployeesGrid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ProfileGrid.EnableHeadersVisualStyles = false;

            // Set the default cell style alignment
            EmployeesGrid.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ProfileGrid.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            // Set the border style for a flat look
            EmployeesGrid.BorderStyle = BorderStyle.None;
            ProfileGrid.BorderStyle = BorderStyle.None;

            // Remove the last blank row
            EmployeesGrid.AllowUserToAddRows = false;
            ProfileGrid.AllowUserToAddRows = false;


        }

    }
}
