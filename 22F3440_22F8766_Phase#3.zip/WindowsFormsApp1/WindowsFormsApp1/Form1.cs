﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;



namespace WindowsFormsApp1
{

    public partial class Form1 : Form
    {
        OracleConnection con;
        int loggedInUserId; // Variable to store the UserID of the logged-in user
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440";
            con = new OracleConnection(conStr);
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OracleCommand selectCmd = con.CreateCommand();
                selectCmd.CommandText = "SELECT UserID, RoleID FROM USERS WHERE USERNAME = :email AND PASSWORD = :password";
                selectCmd.CommandType = CommandType.Text;

                // Bind parameters
                selectCmd.Parameters.Add(":email", OracleDbType.Varchar2).Value = username.Text;
                selectCmd.Parameters.Add(":password", OracleDbType.Varchar2).Value = password.Text;

                OracleDataReader reader = selectCmd.ExecuteReader(); // Execute the query and get the result

                if (reader.Read())
                {
                    loggedInUserId = reader.GetInt32(0); // Get the UserID of the logged-in user
                    int roleId = reader.GetInt32(1); // Get the RoleID of the logged-in user
                    MessageBox.Show("Logged in as User ID: " + loggedInUserId + " Role ID: " + roleId);

                    // Open corresponding form based on role
                    if (roleId == 1) // Patient
                    {
                        // Hide this form and open the patient form
                        this.Hide();
                        Patient patientForm = new Patient(loggedInUserId); // Pass loggedInUserId to Patient form
                        patientForm.Closed += (s, args) => this.Close();
                        patientForm.Show();
                    }
                    else if (roleId == 4 || roleId == 5 || roleId == 6) // Employee
                    {
                        this.Hide();
                        Employee employeeForm = new Employee( loggedInUserId); // Pass loggedInUserId to Employee form
                        employeeForm.Closed += (s, args) => this.Close();
                        employeeForm.Show();
                    }
                    else if (roleId == 3) // Admin
                    {
                        this.Hide();
                        Admin adminForm = new Admin(loggedInUserId); // Pass loggedInUserId to Admin form
                        adminForm.Closed += (s, args) => this.Close();
                        adminForm.Show();
                    }
                    else if(roleId == 7)
                    {
                       //open CustomerSupport.cs form 
                       this.Hide();
                        CustomerSupport customerSupportForm = new CustomerSupport(loggedInUserId);
                        customerSupportForm.Closed += (s, args) => this.Close();
                        customerSupportForm.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Email or Password!");
                }

                reader.Close(); // Close the reader
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }


        }

        private void PatientRegister_Click(object sender, EventArgs e)
        {
            //open the patient registration form
            this.Hide();
            RegisterationForm patientRegisterForm = new RegisterationForm();
            patientRegisterForm.Closed += (s, args) => this.Close();
            patientRegisterForm.Show();

        }
    }
}
