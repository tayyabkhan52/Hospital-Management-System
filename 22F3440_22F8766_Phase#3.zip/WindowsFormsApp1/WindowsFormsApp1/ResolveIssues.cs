﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ResolveIssues : Form
    {
        private int localUserId;
        private int selectedTicId;

        public ResolveIssues(int userId)
        {
            InitializeComponent();
            localUserId = userId;
            LoadData(userId);
            LoadTickets(); 
            CustomizeDataGridView(); 

          
            supportTicketsGridView.SelectionChanged += SupportTicketsGridView_SelectionChanged;
            resolutionStatusCheckbox.Items.AddRange(new string[] { "Open", "In Progress", "Resolved" });
        }

       
        private void LoadData(int userId)
        {
            // Fetch user's full name from the Profiles table using the UserID
            string fullName = "";
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();
                OracleCommand getNameCmd = con.CreateCommand();
                getNameCmd.CommandText = "SELECT FirstName, LastName FROM Profiles WHERE UserID = :userId";
                getNameCmd.Parameters.Add("userId", OracleDbType.Int32).Value = userId;
                OracleDataReader nameReader = getNameCmd.ExecuteReader();
                if (nameReader.Read())
                {
                    fullName = $"{nameReader["FirstName"]} {nameReader["LastName"]}";
                }
                nameReader.Close();
            }
            fullNameLabel.Text = fullName;
        }

        private void ResolveIssues_Load(object sender, EventArgs e)
        {
           
            LoadTickets();
        }

    
        private void LoadTickets()
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();
                OracleDataAdapter adapter = new OracleDataAdapter("SELECT SupportTicketID, SubmittedByUserID, IssueDescription, DateSubmitted, ResolutionStatus FROM CustomerSupport", con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                supportTicketsGridView.DataSource = dt;
            }
        }

        private void SupportTicketsGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (supportTicketsGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow row = supportTicketsGridView.SelectedRows[0];
                selectedTicId = Convert.ToInt32(row.Cells["SupportTicketID"].Value);
                string issueDescription = row.Cells["IssueDescription"].Value.ToString();
                string dateSubmitted = row.Cells["DateSubmitted"].Value.ToString();
                string resolutionStatus = row.Cells["ResolutionStatus"].Value.ToString();

              
                complainDetailsRichTextbox.Text = issueDescription;
                dateLabel.Text = dateSubmitted;
                submittedByUserLabel.Text = fullNameLabel.Text;

                switch (resolutionStatus)
                {
                    case "Open":
                        resolutionStatusCheckbox.SelectedIndex = 0;
                        break;
                    case "In Progress":
                        resolutionStatusCheckbox.SelectedIndex = 1;
                        break;
                    case "Resolved":
                        resolutionStatusCheckbox.SelectedIndex = 2;
                        break;
                }
            }
        }

        private void updateStatusButton_Click(object sender, EventArgs e)
        {
            if (supportTicketsGridView.SelectedRows.Count > 0) { 
                string newStatus = resolutionStatusCheckbox.SelectedItem.ToString();

                using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
                {
                    con.Open();
                    OracleCommand updateStatusCmd = con.CreateCommand();
                    updateStatusCmd.CommandText = "UPDATE CustomerSupport SET ResolutionStatus = :status WHERE SupportTicketID = :ticketId";
                    updateStatusCmd.Parameters.Add("status", OracleDbType.Varchar2).Value = newStatus;
                    updateStatusCmd.Parameters.Add("ticketId", OracleDbType.Int32).Value = selectedTicketId;

                    updateStatusCmd.ExecuteNonQuery();
                    MessageBox.Show("Status updated successfully.");
                }

               
                LoadTickets();
            }
            else
            {
                MessageBox.Show("Please select a support ticket.");
            }
        }


        private void updateButton_Click(object sender, EventArgs e)
        {

            if (supportTicketsGridView.SelectedRows.Count > 0) // Ensure a ticket is selected
            {
                string newStatus = resolutionStatusCheckbox.SelectedItem.ToString();

                using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
                {
                    con.Open();
                    OracleCommand updateStatusCmd = con.CreateCommand();
                    updateStatusCmd.CommandText = "UPDATE CustomerSupport SET ResolutionStatus = :status WHERE SupportTicketID = :ticketId";
                    updateStatusCmd.Parameters.Add("status", OracleDbType.Varchar2).Value = newStatus;
                    updateStatusCmd.Parameters.Add("ticketId", OracleDbType.Int32).Value = selectedTicId; // Use selectedTicId directly

                    updateStatusCmd.ExecuteNonQuery();
                    MessageBox.Show("Status updated successfully.");
                }

                // Refresh the DataGridView to reflect the changes
                LoadTickets();
            }
            else
            {
                MessageBox.Show("Please select a support ticket.");
            }
        }

        private void CustomizeDataGridView()
        {
           
            supportTicketsGridView.BackgroundColor = Color.FromArgb(240, 240, 240);
            supportTicketsGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            supportTicketsGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            supportTicketsGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(65, 105, 225); // RoyalBlue
            supportTicketsGridView.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            supportTicketsGridView.DefaultCellStyle.ForeColor = Color.Black;
            supportTicketsGridView.DefaultCellStyle.BackColor = Color.White;
            supportTicketsGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(245, 245, 245);
            supportTicketsGridView.Columns["SupportTicketID"].HeaderText = "Support Ticket ID";
            supportTicketsGridView.Columns["SubmittedByUserID"].HeaderText = "Submitted By User ID";
            supportTicketsGridView.Columns["IssueDescription"].HeaderText = "Issue Description";
            supportTicketsGridView.Columns["DateSubmitted"].HeaderText = "Date Submitted";
            supportTicketsGridView.Columns["ResolutionStatus"].HeaderText = "Status";
            supportTicketsGridView.DefaultCellStyle.SelectionBackColor = Color.FromArgb(100, 149, 237); // CornflowerBlue
            supportTicketsGridView.DefaultCellStyle.SelectionForeColor = Color.White;    
            supportTicketsGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            supportTicketsGridView.RowHeadersVisible = false;      
            supportTicketsGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
    supportTicketsGridView.BorderStyle = BorderStyle.None;
            supportTicketsGridView.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            supportTicketsGridView.GridColor = Color.LightGray;
        }

    }
}
