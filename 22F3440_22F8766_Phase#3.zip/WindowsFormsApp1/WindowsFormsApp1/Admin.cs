﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Oracle.ManagedDataAccess.Client;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace WindowsFormsApp1
{

    public partial class Admin : Form
    {
        int LocalUserId;
        public Admin(int UserId)
        {
            InitializeComponent();
            //save this UserId
            LocalUserId = UserId;
            LoadAdminProfile();
           
        }




        private void button1_Click(object sender, EventArgs e)
        {
            //hide this form and open the check profiles form
            this.Hide();
            CheckProfiles checkProfilesForm = new CheckProfiles(LocalUserId);
            checkProfilesForm.Closed += (s, args) => this.Close();
            checkProfilesForm.Show();

        }

        private void LoadAdminProfile()
        {
            try
            {
                
                string conStr = @"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440";
                using (OracleConnection con = new OracleConnection(conStr))
                {
                    con.Open();
                 

                    // Fetch admin's profile information from the database using the LocalUserId
                    OracleCommand getAdminProfile = con.CreateCommand();
                    getAdminProfile.CommandText = "SELECT FirstName, LastName FROM PROFILES WHERE UserID = :userId";
                    getAdminProfile.CommandType = CommandType.Text;
                    getAdminProfile.Parameters.Add(":userId", OracleDbType.Int32).Value = LocalUserId;

                    //get result
                    using (OracleDataReader reader = getAdminProfile.ExecuteReader())
                    {
                      
                        if (reader.Read())
                        {
                            string firstName = reader.GetString(0); // Get the value of the FirstName column
                            string lastName = reader.GetString(1); // Get the value of the LastName column
                            int LocalDoctorCount;
                            int LocalPatientCount;
                            int LocaldeptCount;
                          
                            OracleCommand getDoctorCount = con.CreateCommand();
                            getDoctorCount.CommandText = "SELECT COUNT(*) FROM USERS WHERE RoleID = 4";
                            getDoctorCount.CommandType = CommandType.Text;
                            LocalDoctorCount = Convert.ToInt32(getDoctorCount.ExecuteScalar());
                            
                            OracleCommand getPatientCount = con.CreateCommand();
                            getPatientCount.CommandText = "SELECT COUNT(*) FROM USERS WHERE RoleID = 1";
                            getPatientCount.CommandType = CommandType.Text;
                            LocalPatientCount = Convert.ToInt32(getPatientCount.ExecuteScalar());
                            
                            OracleCommand getEmployeeCount = con.CreateCommand();
                            getEmployeeCount.CommandText = "SELECT COUNT(*) FROM USERS WHERE RoleID = 2";
                            getEmployeeCount.CommandType = CommandType.Text;
                          
                            DoctorCount.Text = LocalDoctorCount.ToString(); 
                            PatientCount.Text = LocalPatientCount.ToString();
                            EmployeeCount.Text = getEmployeeCount.ExecuteScalar().ToString();

                            // departments query
                            OracleCommand getDeptCount = con.CreateCommand();
                            getDeptCount.CommandText = "SELECT COUNT(*) FROM DEPARTMENTS";
                            getDeptCount.CommandType = CommandType.Text;
                            LocaldeptCount = Convert.ToInt32(getDeptCount.ExecuteScalar());
              
                            DeptCount.Text = LocaldeptCount.ToString();
                            // Display UserID, name, and current system time on the screen
                            UserIdLabel.Text = "User ID: " + LocalUserId.ToString();
                            nameLabel.Text = firstName + " " + lastName;

                        }
                        else
                        {
                            MessageBox.Show("Admin profile not found.");
                        }
                    }


                    con.Close();
                }
            }
            catch (Exception ex)
            {
 
                MessageBox.Show("Error fetching admin profile information: " + ex.Message);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //open ManageEmployee.cs form
            this.Hide();
            ManageEmployee manageEmployeeForm = new ManageEmployee(LocalUserId);
            manageEmployeeForm.Closed += (s, args) => this.Close();
            manageEmployeeForm.Show();

        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }
        private void label9_Click(object sender, EventArgs e)
        {

        }
        private void GenerateSalaryReportButton_Click(object sender, EventArgs e)
        {
            try
            {
                using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
                {
                    con.Open();
                    string query = "SELECT EmployeeID, FirstName, LastName, Salary FROM Employees JOIN Profiles ON Employees.ProfileID = Profiles.ProfileID";
                    using (OracleCommand cmd = new OracleCommand(query, con))
                    {
                        OracleDataAdapter oda = new OracleDataAdapter(cmd); //  OracleDataAdapter
                        DataTable dt = new DataTable(); // Create a new DataTable to store the result
                        oda.Fill(dt); // Fill the DataTable with the result off query

                        GeneratePDF(dt);
                        MessageBox.Show("Salary report generated successfully.");
                    }
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void GeneratePDF(DataTable dataTable)
        {
            
            Document document = new Document(PageSize.A4);
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\SalaryReport.pdf";
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(path, FileMode.Create));
            document.Open();

            // Add a title to the document
            document.Add(new Paragraph("Salary Report", FontFactory.GetFont("Arial")));
            document.Add(new Paragraph(DateTime.Now.ToString("dd/MM/yyyy"), FontFactory.GetFont("Arial", 12)));
            document.Add(Chunk.NEWLINE); // Add a new line

            // Create a table with columns
            PdfPTable table = new PdfPTable(dataTable.Columns.Count);

            // Add headers to the table
            foreach (DataColumn column in dataTable.Columns)
            {
                PdfPCell cell = new PdfPCell(new Phrase(column.ColumnName));
                cell.BackgroundColor = BaseColor.LIGHT_GRAY; // Set background color
                table.AddCell(cell);
            }

            // Add data rows to the table
            foreach (DataRow row in dataTable.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    table.AddCell(new Phrase(item.ToString()));
                }
            }

            // Add the table to the document
            document.Add(table);
            document.Close();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            //open Appointments.cs form
            this.Hide();
            Appointments appointmentsForm = new Appointments(LocalUserId);
            appointmentsForm.Closed += (s, args) => this.Close();
            appointmentsForm.Show();

        }
    }
}
