﻿using iTextSharp.text.pdf.parser;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class bookAppointment : Form
    {
        private int patientId;
        private int userId;

        public bookAppointment(int patientId, int userId)
        {
            InitializeComponent();
            this.patientId = patientId;
            this.userId = userId;

            LoadDoctors();
        }

        private void LoadDoctors()
        {
            doctorCombo.Items.Clear();

            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();

                OracleCommand getDoctors = con.CreateCommand();
                getDoctors.CommandText = @"SELECT Pr.ProfileID, Pr.FirstName, Pr.LastName 
                                           FROM Profiles Pr 
                                           INNER JOIN Users Us ON Pr.UserID = Us.UserID
                                           WHERE Us.RoleID = 4"; // RoleID 4 represents doctors
                getDoctors.CommandType = CommandType.Text;

                using (OracleDataReader reader = getDoctors.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int profileId = Convert.ToInt32(reader["ProfileID"]);
                        string doctorName = $"{reader["FirstName"]} {reader["LastName"]}";
                        doctorCombo.Items.Add(new Doctor(profileId, doctorName));
                    }
                }
            }
        }

        private bool IsAppointmentSlotAvailable(int doctorProfileId, DateTime selectedDateTime)
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();

                OracleCommand checkSlot = con.CreateCommand();
                checkSlot.CommandText = @"SELECT COUNT(*) 
                                          FROM Appointments 
                                          WHERE EmployeeID = (
                                                SELECT E.EmployeeID 
                                                FROM Employees E 
                                                INNER JOIN Profiles P ON E.ProfileID = P.ProfileID
                                                WHERE P.ProfileID = :doctorProfileId) 
                                          AND ScheduledTime = :selectedDateTime";
                checkSlot.CommandType = CommandType.Text;
                checkSlot.Parameters.Add(":doctorProfileId", OracleDbType.Int32).Value = doctorProfileId;
                checkSlot.Parameters.Add(":selectedDateTime", OracleDbType.Date).Value = selectedDateTime;

                int count = Convert.ToInt32(checkSlot.ExecuteScalar());

                return count == 0;
            }
        }

        private void InsertAppointment(int doctorProfileId, DateTime scheduledTime, DateTime endTime, string purpose)
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();

                // Fetch EmployeeID based on doctor's ProfileID
                OracleCommand getEmployeeId = con.CreateCommand();
                getEmployeeId.CommandText = @"SELECT E.EmployeeID 
                                              FROM Employees E 
                                              INNER JOIN Profiles P ON E.ProfileID = P.ProfileID
                                              WHERE P.ProfileID = :doctorProfileId";
                getEmployeeId.CommandType = CommandType.Text;
                getEmployeeId.Parameters.Add(":doctorProfileId", OracleDbType.Int32).Value = doctorProfileId;

                int employeeId = Convert.ToInt32(getEmployeeId.ExecuteScalar());

                // Insert appointment into Appointments table
                OracleCommand insertAppointment = con.CreateCommand();
                insertAppointment.CommandText = @"INSERT INTO Appointments (PatientID, EmployeeID, ScheduledTime, EndTime, Purpose, Status)
                                                  VALUES (:patientId, :employeeId, :scheduledTime, :endTime, :purpose, 'Scheduled')";
                insertAppointment.CommandType = CommandType.Text;
                insertAppointment.Parameters.Add(":patientId", OracleDbType.Int32).Value = patientId;
                insertAppointment.Parameters.Add(":employeeId", OracleDbType.Int32).Value = employeeId;
                insertAppointment.Parameters.Add(":scheduledTime", OracleDbType.Date).Value = scheduledTime;
                insertAppointment.Parameters.Add(":endTime", OracleDbType.Date).Value = endTime;
                insertAppointment.Parameters.Add(":purpose", OracleDbType.Varchar2).Value = purpose;

                int rowsInserted = insertAppointment.ExecuteNonQuery();

                if (rowsInserted > 0)
                {
                    statusLabel.Text = "Scheduled";
                    MessageBox.Show("Appointment added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Failed to add appointment.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Patient patientForm = new Patient(userId);
            patientForm.Closed += (s, args) => this.Close();
            patientForm.Show();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            Doctor selectedDoctor = (Doctor)doctorCombo.SelectedItem;
            DateTime selectedDateTime = dateTimePicker.Value;
            string purpose = richTextBox.Text;

            DateTime endTime = selectedDateTime.AddMinutes(30);

            if (IsAppointmentSlotAvailable(selectedDoctor.ProfileId, selectedDateTime))
            {
                InsertAppointment(selectedDoctor.ProfileId, selectedDateTime, endTime, purpose);
            }
            else
            {
                statusLabel.Text = "Slot already taken.";
                MessageBox.Show("Appointment slot is already taken. Please select another date/time.", "Slot Taken", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        // Add this method to the bookAppointment.Designer.cs file
        private void bookAppointment_Load(object sender, EventArgs e)
        {
            // This method might contain designer-generated code
        }

        
        public class Doctor
        {
            public int ProfileId { get; }
            public string Name { get; }

            public Doctor(int profileId, string name)
            {
                ProfileId = profileId;
                Name = name;
            }

            public override string ToString()
            {
                return Name;
            }
        }
    }
}
