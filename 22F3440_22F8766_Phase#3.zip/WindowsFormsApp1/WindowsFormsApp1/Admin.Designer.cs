﻿namespace WindowsFormsApp1
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.CheckProfileButton = new System.Windows.Forms.Button();
            this.nameLabel = new System.Windows.Forms.Label();
            this.adminDashboardLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ManageEmployeesButton = new System.Windows.Forms.Button();
            this.UserIdLabel = new System.Windows.Forms.Label();
            this.PatientIcon = new System.Windows.Forms.Label();
            this.TotalPatientsText = new System.Windows.Forms.Label();
            this.PatientCount = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TotalEmployeeText = new System.Windows.Forms.Label();
            this.EmployeeCount = new System.Windows.Forms.Label();
            this.EmployeeIcon = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TotalDoctorsText = new System.Windows.Forms.Label();
            this.DoctorCount = new System.Windows.Forms.Label();
            this.DoctorIcon = new System.Windows.Forms.Label();
            this.DeptCount = new System.Windows.Forms.Label();
            this.TotalDepartmentsText = new System.Windows.Forms.Label();
            this.DepartmentIcon = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.GenerateSalaryReportButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CheckProfileButton
            // 
            this.CheckProfileButton.BackColor = System.Drawing.SystemColors.ControlText;
            this.CheckProfileButton.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckProfileButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.CheckProfileButton.Location = new System.Drawing.Point(25, 30);
            this.CheckProfileButton.Name = "CheckProfileButton";
            this.CheckProfileButton.Size = new System.Drawing.Size(157, 61);
            this.CheckProfileButton.TabIndex = 1;
            this.CheckProfileButton.Text = "Edit Profile";
            this.CheckProfileButton.UseVisualStyleBackColor = false;
            this.CheckProfileButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // nameLabel
            // 
            this.nameLabel.BackColor = System.Drawing.Color.Linen;
            this.nameLabel.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(1061, 76);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(157, 26);
            this.nameLabel.TabIndex = 3;
            this.nameLabel.Text = "Name";
            this.nameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // adminDashboardLabel
            // 
            this.adminDashboardLabel.BackColor = System.Drawing.Color.RoyalBlue;
            this.adminDashboardLabel.Dock = System.Windows.Forms.DockStyle.Top;
            this.adminDashboardLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adminDashboardLabel.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminDashboardLabel.ForeColor = System.Drawing.Color.White;
            this.adminDashboardLabel.Image = ((System.Drawing.Image)(resources.GetObject("adminDashboardLabel.Image")));
            this.adminDashboardLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.adminDashboardLabel.Location = new System.Drawing.Point(0, 0);
            this.adminDashboardLabel.Name = "adminDashboardLabel";
            this.adminDashboardLabel.Padding = new System.Windows.Forms.Padding(5);
            this.adminDashboardLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.adminDashboardLabel.Size = new System.Drawing.Size(1233, 60);
            this.adminDashboardLabel.TabIndex = 5;
            this.adminDashboardLabel.Text = "ADMIN DASHBOARD";
            this.adminDashboardLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.GenerateSalaryReportButton);
            this.panel1.Controls.Add(this.ManageEmployeesButton);
            this.panel1.Controls.Add(this.CheckProfileButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(206, 507);
            this.panel1.TabIndex = 6;
            // 
            // ManageEmployeesButton
            // 
            this.ManageEmployeesButton.BackColor = System.Drawing.SystemColors.ControlText;
            this.ManageEmployeesButton.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageEmployeesButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ManageEmployeesButton.Location = new System.Drawing.Point(25, 97);
            this.ManageEmployeesButton.Name = "ManageEmployeesButton";
            this.ManageEmployeesButton.Size = new System.Drawing.Size(157, 64);
            this.ManageEmployeesButton.TabIndex = 2;
            this.ManageEmployeesButton.Text = "Manage Employees";
            this.ManageEmployeesButton.UseVisualStyleBackColor = false;
            this.ManageEmployeesButton.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // UserIdLabel
            // 
            this.UserIdLabel.BackColor = System.Drawing.Color.Linen;
            this.UserIdLabel.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIdLabel.Location = new System.Drawing.Point(908, 76);
            this.UserIdLabel.Name = "UserIdLabel";
            this.UserIdLabel.Size = new System.Drawing.Size(137, 26);
            this.UserIdLabel.TabIndex = 2;
            this.UserIdLabel.Text = "UserName";
            this.UserIdLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PatientIcon
            // 
            this.PatientIcon.BackColor = System.Drawing.Color.MediumTurquoise;
            this.PatientIcon.Image = ((System.Drawing.Image)(resources.GetObject("PatientIcon.Image")));
            this.PatientIcon.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.PatientIcon.Location = new System.Drawing.Point(477, 266);
            this.PatientIcon.Name = "PatientIcon";
            this.PatientIcon.Size = new System.Drawing.Size(61, 59);
            this.PatientIcon.TabIndex = 7;
            // 
            // TotalPatientsText
            // 
            this.TotalPatientsText.AutoSize = true;
            this.TotalPatientsText.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TotalPatientsText.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalPatientsText.Location = new System.Drawing.Point(322, 256);
            this.TotalPatientsText.Name = "TotalPatientsText";
            this.TotalPatientsText.Size = new System.Drawing.Size(141, 28);
            this.TotalPatientsText.TabIndex = 8;
            this.TotalPatientsText.Text = "Total Patients";
            // 
            // PatientCount
            // 
            this.PatientCount.BackColor = System.Drawing.Color.MediumTurquoise;
            this.PatientCount.Font = new System.Drawing.Font("Nirmala UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatientCount.Location = new System.Drawing.Point(323, 293);
            this.PatientCount.Name = "PatientCount";
            this.PatientCount.Size = new System.Drawing.Size(136, 32);
            this.PatientCount.TabIndex = 9;
            this.PatientCount.Text = "Pat Count";
            this.PatientCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(297, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(258, 97);
            this.label5.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Location = new System.Drawing.Point(589, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(259, 97);
            this.label4.TabIndex = 11;
            // 
            // TotalEmployeeText
            // 
            this.TotalEmployeeText.AutoSize = true;
            this.TotalEmployeeText.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TotalEmployeeText.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalEmployeeText.Location = new System.Drawing.Point(595, 256);
            this.TotalEmployeeText.Name = "TotalEmployeeText";
            this.TotalEmployeeText.Size = new System.Drawing.Size(166, 28);
            this.TotalEmployeeText.TabIndex = 12;
            this.TotalEmployeeText.Text = "Total Employees";
            // 
            // EmployeeCount
            // 
            this.EmployeeCount.BackColor = System.Drawing.Color.NavajoWhite;
            this.EmployeeCount.Font = new System.Drawing.Font("Nirmala UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeCount.Location = new System.Drawing.Point(607, 293);
            this.EmployeeCount.Name = "EmployeeCount";
            this.EmployeeCount.Size = new System.Drawing.Size(136, 32);
            this.EmployeeCount.TabIndex = 13;
            this.EmployeeCount.Text = "Emp Count";
            this.EmployeeCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EmployeeIcon
            // 
            this.EmployeeIcon.BackColor = System.Drawing.Color.NavajoWhite;
            this.EmployeeIcon.Image = ((System.Drawing.Image)(resources.GetObject("EmployeeIcon.Image")));
            this.EmployeeIcon.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.EmployeeIcon.Location = new System.Drawing.Point(771, 265);
            this.EmployeeIcon.Name = "EmployeeIcon";
            this.EmployeeIcon.Size = new System.Drawing.Size(61, 59);
            this.EmployeeIcon.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Location = new System.Drawing.Point(871, 245);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(259, 97);
            this.label7.TabIndex = 15;
            // 
            // TotalDoctorsText
            // 
            this.TotalDoctorsText.AutoSize = true;
            this.TotalDoctorsText.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TotalDoctorsText.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalDoctorsText.Location = new System.Drawing.Point(892, 256);
            this.TotalDoctorsText.Name = "TotalDoctorsText";
            this.TotalDoctorsText.Size = new System.Drawing.Size(139, 28);
            this.TotalDoctorsText.TabIndex = 16;
            this.TotalDoctorsText.Text = "Total Doctors";
            this.TotalDoctorsText.Click += new System.EventHandler(this.label9_Click);
            // 
            // DoctorCount
            // 
            this.DoctorCount.BackColor = System.Drawing.Color.Salmon;
            this.DoctorCount.Font = new System.Drawing.Font("Nirmala UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoctorCount.Location = new System.Drawing.Point(895, 293);
            this.DoctorCount.Name = "DoctorCount";
            this.DoctorCount.Size = new System.Drawing.Size(136, 32);
            this.DoctorCount.TabIndex = 17;
            this.DoctorCount.Text = "Doctor Count";
            this.DoctorCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DoctorIcon
            // 
            this.DoctorIcon.BackColor = System.Drawing.Color.Salmon;
            this.DoctorIcon.Image = ((System.Drawing.Image)(resources.GetObject("DoctorIcon.Image")));
            this.DoctorIcon.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DoctorIcon.Location = new System.Drawing.Point(1053, 265);
            this.DoctorIcon.Name = "DoctorIcon";
            this.DoctorIcon.Size = new System.Drawing.Size(61, 59);
            this.DoctorIcon.TabIndex = 18;
            // 
            // DeptCount
            // 
            this.DeptCount.BackColor = System.Drawing.Color.SpringGreen;
            this.DeptCount.Font = new System.Drawing.Font("Nirmala UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeptCount.Location = new System.Drawing.Point(615, 435);
            this.DeptCount.Name = "DeptCount";
            this.DeptCount.Size = new System.Drawing.Size(136, 32);
            this.DeptCount.TabIndex = 21;
            this.DeptCount.Text = "Dept Count";
            this.DeptCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TotalDepartmentsText
            // 
            this.TotalDepartmentsText.AutoSize = true;
            this.TotalDepartmentsText.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TotalDepartmentsText.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalDepartmentsText.Location = new System.Drawing.Point(614, 398);
            this.TotalDepartmentsText.Name = "TotalDepartmentsText";
            this.TotalDepartmentsText.Size = new System.Drawing.Size(136, 28);
            this.TotalDepartmentsText.TabIndex = 20;
            this.TotalDepartmentsText.Text = "Departments";
            // 
            // DepartmentIcon
            // 
            this.DepartmentIcon.BackColor = System.Drawing.Color.SpringGreen;
            this.DepartmentIcon.Image = ((System.Drawing.Image)(resources.GetObject("DepartmentIcon.Image")));
            this.DepartmentIcon.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DepartmentIcon.Location = new System.Drawing.Point(770, 408);
            this.DepartmentIcon.Name = "DepartmentIcon";
            this.DepartmentIcon.Size = new System.Drawing.Size(61, 59);
            this.DepartmentIcon.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label14.Location = new System.Drawing.Point(589, 387);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(259, 97);
            this.label14.TabIndex = 22;
            // 
            // GenerateSalaryReportButton
            // 
            this.GenerateSalaryReportButton.BackColor = System.Drawing.SystemColors.ControlText;
            this.GenerateSalaryReportButton.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenerateSalaryReportButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.GenerateSalaryReportButton.Location = new System.Drawing.Point(25, 167);
            this.GenerateSalaryReportButton.Name = "GenerateSalaryReportButton";
            this.GenerateSalaryReportButton.Size = new System.Drawing.Size(157, 64);
            this.GenerateSalaryReportButton.TabIndex = 3;
            this.GenerateSalaryReportButton.Text = "Salary Report";
            this.GenerateSalaryReportButton.UseVisualStyleBackColor = false;
            this.GenerateSalaryReportButton.Click += new System.EventHandler(this.GenerateSalaryReportButton_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlText;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(25, 237);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(157, 64);
            this.button1.TabIndex = 4;
            this.button1.Text = "Appointments";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1233, 567);
            this.Controls.Add(this.DeptCount);
            this.Controls.Add(this.TotalDepartmentsText);
            this.Controls.Add(this.DepartmentIcon);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.DoctorIcon);
            this.Controls.Add(this.DoctorCount);
            this.Controls.Add(this.TotalDoctorsText);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.EmployeeIcon);
            this.Controls.Add(this.EmployeeCount);
            this.Controls.Add(this.TotalEmployeeText);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PatientCount);
            this.Controls.Add(this.TotalPatientsText);
            this.Controls.Add(this.PatientIcon);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.adminDashboardLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.UserIdLabel);
            this.Controls.Add(this.label5);
            this.Name = "Admin";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button CheckProfileButton;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label adminDashboardLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label UserIdLabel;
        private System.Windows.Forms.Button ManageEmployeesButton;
        private System.Windows.Forms.Label PatientIcon;
        private System.Windows.Forms.Label TotalPatientsText;
        private System.Windows.Forms.Label PatientCount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label TotalEmployeeText;
        private System.Windows.Forms.Label EmployeeCount;
        private System.Windows.Forms.Label EmployeeIcon;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label TotalDoctorsText;
        private System.Windows.Forms.Label DoctorCount;
        private System.Windows.Forms.Label DoctorIcon;
        private System.Windows.Forms.Label DeptCount;
        private System.Windows.Forms.Label TotalDepartmentsText;
        private System.Windows.Forms.Label DepartmentIcon;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button GenerateSalaryReportButton;
        private System.Windows.Forms.Button button1;
    }
}