﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CustomerSupport : Form
    {
        private int localUserId;

        public CustomerSupport(int userId)
        {
            InitializeComponent();
            localUserId = userId;
            LoadData(userId);
        }

        private void CustomerSupport_Load(object sender, EventArgs e)
        {

        }

        void LoadData(int userId)
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();

                // Fetch patient's profile information from the database using the userId
                OracleCommand getPatientProfile = con.CreateCommand();
                getPatientProfile.CommandText = @"SELECT Pr.FirstName,
                                                       Pr.LastName,
                                                       Pr.Email,
                                                       Pr.PhoneNumber,
                                                       Pr.DateOfBirth,
                                                       E.EmployeeID
                                                FROM Profiles Pr
                                                INNER JOIN Employees E ON Pr.ProfileID = E.ProfileID
                                                INNER JOIN Users Us ON Pr.UserID = Us.UserID
                                                WHERE Us.UserID = :userId";
                getPatientProfile.CommandType = CommandType.Text;
                getPatientProfile.Parameters.Add("userId", OracleDbType.Int32).Value = userId;

                // Execute the command
                OracleDataReader reader = getPatientProfile.ExecuteReader();

                // Check if data is returned
                if (reader.Read())
                {
                    // Fill the labels with retrieved data
                    UserName.Text = $"{reader["FirstName"]} {reader["LastName"]}";
                    emailLabel.Text = reader["Email"].ToString();
                    phoneLabel.Text = reader["PhoneNumber"].ToString();
                    dobLabel.Text = Convert.ToDateTime(reader["DateOfBirth"]).ToShortDateString();
                    employeeId.Text = reader["EmployeeID"].ToString();
                    userIdLabel.Text = userId.ToString();
                }
                else
                {
                    MessageBox.Show("Patient data not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                // Close the data reader and connection
                reader.Close();
                con.Close();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            ResolveIssues resolveIssues = new ResolveIssues(localUserId);
            resolveIssues.Closed += (s, args) => this.Close();
            resolveIssues.Show();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Create a new PDF document
            Document doc = new Document(PageSize.A4, 20f, 20f, 30f, 30f);

            try
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filePath = Path.Combine(desktopPath, "CustomerSupportReport.pdf");

                // Use a FileStream with using statement to ensure proper closing and disposal
                using (FileStream fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    PdfWriter writer = PdfWriter.GetInstance(doc, fileStream);

                    // Open the document
                    doc.Open();

                    // Add a title to the document
                    Paragraph title = new Paragraph("Customer Support Report", FontFactory.GetFont("Arial", 20));
                    title.Alignment = Element.ALIGN_CENTER;
                    doc.Add(title);
                    doc.Add(Chunk.NEWLINE);

                    // Fetch data from the database
                    DataTable supportTicketsTable = FetchSupportTicketsData();

                    // Check if the DataTable has rows
                    if (supportTicketsTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No support tickets found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        // Add table for support tickets
                        AddSupportTicketsTable(doc, supportTicketsTable);
                    }

                    // Close the document after writing is completed
                    doc.Close();
                }

                MessageBox.Show("Report generated successfully!\n\nThe report has been saved to your desktop.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error generating report: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private DataTable FetchSupportTicketsData()
        {
            DataTable supportTicketsTable = new DataTable();
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();
                OracleDataAdapter adapter = new OracleDataAdapter("SELECT * FROM CustomerSupport", con);
                adapter.Fill(supportTicketsTable);
            }
            return supportTicketsTable;
        }

        private void AddSupportTicketsTable(Document doc, DataTable tickets)
        {
            // Create table
            PdfPTable table = new PdfPTable(tickets.Columns.Count);
            table.WidthPercentage = 100;

            // Add headers
            foreach (DataColumn column in tickets.Columns)
            {
                PdfPCell cell = new PdfPCell(new Phrase(column.ColumnName, FontFactory.GetFont("Arial", 12)));
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                cell.BackgroundColor = new BaseColor(230, 230, 230); // Light gray background
                table.AddCell(cell);
            }

            // Add rows
            foreach (DataRow row in tickets.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(item.ToString(), FontFactory.GetFont("Arial", 10)));
                    table.AddCell(cell);
                }
            }

            // Add table to document
            doc.Add(table);
            doc.Add(Chunk.NEWLINE);
        }

        private void medicalHistoryButton_Click(object sender, EventArgs e)
        {
            //open checkProfile form with the userId and close this one
            this.Hide();
            CheckProfiles checkProfile = new CheckProfiles(localUserId);
            checkProfile.Closed += (s, args) => this.Close();
            checkProfile.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            Form1 form1 = new Form1();
            form1.Closed += (s, args) => this.Close();
            form1.Show();
        }
    }
}
