﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    
    public partial class TrackAppointment : Form
    {
        int userId;
        public TrackAppointment(int UserId)
        {
            InitializeComponent();
            //save this UserId
            userId = UserId;
        }

        private void TrackAppointment_Load(object sender, EventArgs e)
        {
            // Load data when the form loads
            LoadData(dateTimePicker1.Value.Date);
        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            // Load data when the selected date changes
            LoadData(dateTimePicker1.Value.Date);
        }
        void LoadData(DateTime selectedDate)
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();

                // Fetch appointment information for the selected date
                OracleCommand getAppointmentInfo = con.CreateCommand();
                getAppointmentInfo.CommandText = @"SELECT A.AppointmentID,
                                                           A.ScheduledTime,
                                                           A.Purpose,
                                                           A.Status,
                                                           E.EmployeeID,
                                                           P.FirstName || ' ' || P.LastName AS DoctorName
                                                    FROM Appointments A
                                                    INNER JOIN Employees E ON A.EmployeeID = E.EmployeeID
                                                    INNER JOIN Profiles P ON E.ProfileID = P.ProfileID
                                                    WHERE TRUNC(A.ScheduledTime) = :selectedDate";
                getAppointmentInfo.CommandType = CommandType.Text;
                getAppointmentInfo.Parameters.Add(":selectedDate", OracleDbType.Date).Value = selectedDate;

                // Execute the command
                OracleDataReader reader = getAppointmentInfo.ExecuteReader();

                // Check if data is returned
                if (reader.Read())
                {
                    // Fill the labels with retrieved data
                    appointmentIDLabel.Text = reader["AppointmentID"].ToString();
                    purposeLabel.Text = reader["Purpose"].ToString();
                    statusLabel.Text = reader["Status"].ToString();
                    DoctornameLabel.Text = reader["DoctorName"].ToString();
                }
                else
                {
                    // If no data is returned, display a message
                    appointmentIDLabel.Text = "-";
                    purposeLabel.Text = "-";
                    statusLabel.Text = "-";
                    DoctornameLabel.Text = "No appointments found for selected date.";
                }

                // Close the data reader and connection
                reader.Close();
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //close this form upon going back to the patient form with the same userId
            this.Hide();
            Patient patientForm = new Patient(userId);
            patientForm.Closed += (s, args) => this.Close();
            patientForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //call the LoadData
            LoadData(dateTimePicker1.Value.Date);
        }
    }
}
