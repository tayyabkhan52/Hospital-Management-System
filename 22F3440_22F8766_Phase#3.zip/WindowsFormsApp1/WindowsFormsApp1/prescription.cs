﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class prescription : Form
    {
        private int LocalUserId;
        private int PatientId;

        public prescription(int Userid, int patientId)
        {
            LocalUserId = Userid;
            InitializeComponent();
            PatientId = patientId;

            // Load prescriptions for the patient when the form loads
            LoadPrescriptions();
            CustomizeDataGridView();
        }

        private void LoadPrescriptions()
        {
            // Ensure prescriptionsDataGridView is not null
            if (prescriptionsDataGridView != null)
            {
                using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
                {
                    con.Open();

                    // Fetch prescriptions for the patient
                    OracleCommand getPrescriptions = con.CreateCommand();
                    getPrescriptions.CommandText = @"SELECT PrescriptionID, Medication, UsageInstructions, DatePrescribed
                                                     FROM PRESCRIPTIONS
                                                     WHERE PatientID = :patientId";
                    getPrescriptions.Parameters.Add(":patientId", OracleDbType.Int32).Value = PatientId;

                    // Load data into the DataGridView
                    using (OracleDataReader reader = getPrescriptions.ExecuteReader())
                    {
                        DataTable dt = new DataTable();
                        dt.Load(reader);
                        prescriptionsDataGridView.DataSource = dt;
                    }

                    // Close the connection
                    con.Close();
                }

                // Hide unnecessary columns
                if (prescriptionsDataGridView.Columns["PrescriptionID"] != null)
                    prescriptionsDataGridView.Columns["PrescriptionID"].Visible = false;

                if (prescriptionsDataGridView.Columns["PatientID"] != null)
                    prescriptionsDataGridView.Columns["PatientID"].Visible = false;

                // Make the headers professional
                if (prescriptionsDataGridView.Columns["Medication"] != null)
                    prescriptionsDataGridView.Columns["Medication"].HeaderText = "Medication";

                if (prescriptionsDataGridView.Columns["UsageInstructions"] != null)
                    prescriptionsDataGridView.Columns["UsageInstructions"].HeaderText = "Usage Instructions";

                if (prescriptionsDataGridView.Columns["DatePrescribed"] != null)
                    prescriptionsDataGridView.Columns["DatePrescribed"].HeaderText = "Date Prescribed";
            }
        }

        private void prescription_Load(object sender, EventArgs e)
        {
            // Load prescriptions for the patient when the form loads
            LoadPrescriptions();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //open patient form with this userId and close this one
            this.Hide();
            Patient patientForm = new Patient(LocalUserId);
            patientForm.Closed += (s, args) => this.Close();
            patientForm.Show();
        }

        private void CustomizeDataGridView()
        {
            // Set the font for readability
            prescriptionsDataGridView.DefaultCellStyle.Font = new Font("Segoe UI", 8);
            prescriptionsDataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 7);

            // Purple and white color scheme
            prescriptionsDataGridView.BackgroundColor = Color.White;
            prescriptionsDataGridView.GridColor = Color.Lavender;
            prescriptionsDataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.MediumPurple;
            prescriptionsDataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set the RowHeaders to be invisible if not needed
            prescriptionsDataGridView.RowHeadersVisible = false;

            // Set grid lines for better separation of data
            prescriptionsDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            prescriptionsDataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;

            // Adjust row height
            prescriptionsDataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            prescriptionsDataGridView.RowTemplate.Height = 30; // Set this to a suitable height

            // Highlight the selected row
            prescriptionsDataGridView.DefaultCellStyle.SelectionBackColor = Color.DarkOrchid; // A professional purple color
            prescriptionsDataGridView.DefaultCellStyle.SelectionForeColor = Color.White;

            // Use alternating row style
            prescriptionsDataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.LavenderBlush; // A light purple tint
            prescriptionsDataGridView.AlternatingRowsDefaultCellStyle.ForeColor = Color.Black;

            // Auto-Size columns based on content
            prescriptionsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Make the grid read-only if you don't want users to edit it directly
            prescriptionsDataGridView.ReadOnly = true;

            // Enable row headers to select rows if needed
            prescriptionsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Reduce padding for a cleaner look
            prescriptionsDataGridView.DefaultCellStyle.Padding = new Padding(5);

            // Set the height for column headers
            prescriptionsDataGridView.ColumnHeadersHeight = 35;

            // Set wrap mode for text
            prescriptionsDataGridView.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            // Improve the look of the header cells
            prescriptionsDataGridView.EnableHeadersVisualStyles = false;
            prescriptionsDataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set the default cell style alignment
            prescriptionsDataGridView.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            // Set the border style for a flat look
            prescriptionsDataGridView.BorderStyle = BorderStyle.None;

            // Remove the last blank row
            prescriptionsDataGridView.AllowUserToAddRows = false;
        }

    }
}
