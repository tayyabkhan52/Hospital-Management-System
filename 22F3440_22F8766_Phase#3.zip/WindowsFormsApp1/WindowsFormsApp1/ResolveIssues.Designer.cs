﻿namespace WindowsFormsApp1
{
    partial class ResolveIssues
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.supportTicketsGridView = new System.Windows.Forms.DataGridView();
            this.resolutionStatusCheckbox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.selectedTicketId = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.submittedByUserLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.complainDetailsRichTextbox = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dateLabel = new System.Windows.Forms.Label();
            this.updateButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.fullNameLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.supportTicketsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // supportTicketsGridView
            // 
            this.supportTicketsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.supportTicketsGridView.Location = new System.Drawing.Point(620, 36);
            this.supportTicketsGridView.Name = "supportTicketsGridView";
            this.supportTicketsGridView.RowHeadersWidth = 51;
            this.supportTicketsGridView.RowTemplate.Height = 24;
            this.supportTicketsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.supportTicketsGridView.Size = new System.Drawing.Size(670, 463);
            this.supportTicketsGridView.TabIndex = 0;
            this.supportTicketsGridView.VirtualMode = true;
            // 
            // resolutionStatusCheckbox
            // 
            this.resolutionStatusCheckbox.FormattingEnabled = true;
            this.resolutionStatusCheckbox.Location = new System.Drawing.Point(292, 115);
            this.resolutionStatusCheckbox.Name = "resolutionStatusCheckbox";
            this.resolutionStatusCheckbox.Size = new System.Drawing.Size(180, 24);
            this.resolutionStatusCheckbox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(54, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(217, 24);
            this.label2.TabIndex = 40;
            this.label2.Text = "Change Resolution Status:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(54, 153);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 24);
            this.label1.TabIndex = 41;
            this.label1.Text = "Ticket ID:";
            // 
            // selectedTicketId
            // 
            this.selectedTicketId.AutoSize = true;
            this.selectedTicketId.BackColor = System.Drawing.Color.Transparent;
            this.selectedTicketId.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.selectedTicketId.ForeColor = System.Drawing.Color.Red;
            this.selectedTicketId.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.selectedTicketId.Location = new System.Drawing.Point(142, 153);
            this.selectedTicketId.Name = "selectedTicketId";
            this.selectedTicketId.Size = new System.Drawing.Size(82, 24);
            this.selectedTicketId.TabIndex = 42;
            this.selectedTicketId.Text = "Ticket ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(54, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 24);
            this.label4.TabIndex = 43;
            this.label4.Text = "Submitted By:";
            // 
            // submittedByUserLabel
            // 
            this.submittedByUserLabel.AutoSize = true;
            this.submittedByUserLabel.BackColor = System.Drawing.Color.Transparent;
            this.submittedByUserLabel.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.submittedByUserLabel.ForeColor = System.Drawing.Color.Red;
            this.submittedByUserLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.submittedByUserLabel.Location = new System.Drawing.Point(179, 187);
            this.submittedByUserLabel.Name = "submittedByUserLabel";
            this.submittedByUserLabel.Size = new System.Drawing.Size(114, 24);
            this.submittedByUserLabel.TabIndex = 44;
            this.submittedByUserLabel.Text = "Submitted By";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(54, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 24);
            this.label6.TabIndex = 45;
            this.label6.Text = "Complain Details:";
            // 
            // complainDetailsRichTextbox
            // 
            this.complainDetailsRichTextbox.Location = new System.Drawing.Point(58, 256);
            this.complainDetailsRichTextbox.Name = "complainDetailsRichTextbox";
            this.complainDetailsRichTextbox.Size = new System.Drawing.Size(383, 112);
            this.complainDetailsRichTextbox.TabIndex = 46;
            this.complainDetailsRichTextbox.Text = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(273, 153);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 24);
            this.label7.TabIndex = 47;
            this.label7.Text = "Date Submitted:";
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.BackColor = System.Drawing.Color.Transparent;
            this.dateLabel.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel.ForeColor = System.Drawing.Color.Red;
            this.dateLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dateLabel.Location = new System.Drawing.Point(427, 153);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(45, 24);
            this.dateLabel.TabIndex = 48;
            this.dateLabel.Text = "Date";
            // 
            // updateButton
            // 
            this.updateButton.BackColor = System.Drawing.Color.Moccasin;
            this.updateButton.Font = new System.Drawing.Font("Arial", 10.2F);
            this.updateButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.updateButton.Location = new System.Drawing.Point(31, 498);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(168, 41);
            this.updateButton.TabIndex = 49;
            this.updateButton.Text = "Update Status";
            this.updateButton.UseVisualStyleBackColor = false;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(54, 395);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 24);
            this.label3.TabIndex = 50;
            this.label3.Text = "Full Name:";
            // 
            // fullNameLabel
            // 
            this.fullNameLabel.AutoSize = true;
            this.fullNameLabel.BackColor = System.Drawing.Color.Transparent;
            this.fullNameLabel.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.fullNameLabel.ForeColor = System.Drawing.Color.Red;
            this.fullNameLabel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.fullNameLabel.Location = new System.Drawing.Point(152, 395);
            this.fullNameLabel.Name = "fullNameLabel";
            this.fullNameLabel.Size = new System.Drawing.Size(92, 24);
            this.fullNameLabel.TabIndex = 51;
            this.fullNameLabel.Text = "Full Name:";
            // 
            // ResolveIssues
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1316, 563);
            this.Controls.Add(this.fullNameLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.complainDetailsRichTextbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.submittedByUserLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.selectedTicketId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.resolutionStatusCheckbox);
            this.Controls.Add(this.supportTicketsGridView);
            this.Name = "ResolveIssues";
            this.Text = "ResolveIssues";
            this.Load += new System.EventHandler(this.ResolveIssues_Load);
            ((System.ComponentModel.ISupportInitialize)(this.supportTicketsGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox resolutionStatusCheckbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label selectedTicketId;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label submittedByUserLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox complainDetailsRichTextbox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label fullNameLabel;
        public System.Windows.Forms.DataGridView supportTicketsGridView;
    }
}