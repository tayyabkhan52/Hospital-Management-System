﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;


namespace WindowsFormsApp1
{
    public partial class Appointments : Form
    {
        int LocalUserId;
        public Appointments(int userId)
        {
            InitializeComponent();
            LocalUserId = userId;
            AppointmentsGrid.SelectionChanged += AppointmentsGrid_SelectionChanged;
            CustomizeDataGridView();

        }

        private void Appointments_Load(object sender, EventArgs e)
        {
            // Load the appointments from the database
            string conStr = @"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440";
            using (OracleConnection con = new OracleConnection(conStr))
            {
                con.Open();

                    //load data from database from appointments table
                    OracleDataAdapter adapter = new OracleDataAdapter($"SELECT * FROM APPOINTMENTS", con);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    AppointmentsGrid.DataSource = dt;
                //hide patient id and employee id columns
                AppointmentsGrid.Columns["PATIENTID"].Visible = false;
                AppointmentsGrid.Columns["EMPLOYEEID"].Visible = false;

                //extract the patient profile information and display in the textboxes, also extarct the employee name from the employee table and display name of doctor in the textbox
                foreach (DataGridViewRow row in AppointmentsGrid.Rows)
                {
                   
                    int patientId = Convert.ToInt32(row.Cells["PATIENTID"].Value);
                    int employeeId = Convert.ToInt32(row.Cells["EMPLOYEEID"].Value);

                    //get the patient profile information
                    OracleCommand getPatientProfile = con.CreateCommand();
                    getPatientProfile.CommandText = "SELECT FirstName, LastName FROM PROFILES WHERE UserID = :userId";
                    getPatientProfile.CommandType = CommandType.Text;
                    getPatientProfile.Parameters.Add(":userId", OracleDbType.Int32).Value = patientId;
                    OracleDataReader reader = getPatientProfile.ExecuteReader();
                    if (reader.Read())
                    {
                        row.Cells["PATIENT"].Value = reader.GetString(0) + " " + reader.GetString(1);
                    }
                    reader.Close();

                    //get the employee name
                    OracleCommand getEmployeeName = con.CreateCommand();
                    getEmployeeName.CommandText = "SELECT FirstName, LastName FROM PROFILES WHERE UserID = :userId";
                    getEmployeeName.CommandType = CommandType.Text;
                    getEmployeeName.Parameters.Add(":userId", OracleDbType.Int32).Value = employeeId;
                    reader = getEmployeeName.ExecuteReader();
                    if (reader.Read())
                    {
                        row.Cells["DOCTOR"].Value = reader.GetString(0) + " " + reader.GetString(1);
                    }
                    reader.Close();
                }
                
            }
        }

        //appointmentsGrid_CellContentClick

        private void AppointmentsGrid_CellContentClick(object sender, EventArgs e) { }

        private void AppointmentsGrid_SelectionChanged(object sender, EventArgs e)
        {
            if (AppointmentsGrid.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = AppointmentsGrid.SelectedRows[0];

                int patientId = Convert.ToInt32(selectedRow.Cells["PatientID"].Value);
                int employeeId = Convert.ToInt32(selectedRow.Cells["EmployeeID"].Value);

                string conStr = @"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440";
                using (OracleConnection con = new OracleConnection(conStr))
                {
                    con.Open();

                    // Fetch patient ProfileID
                    int patientProfileId;
                    OracleCommand getPatientProfileId = new OracleCommand("SELECT ProfileID FROM PATIENTS WHERE PatientID = :patientId", con);
                    getPatientProfileId.Parameters.Add(":patientId", OracleDbType.Int32).Value = patientId;
                    patientProfileId = Convert.ToInt32(getPatientProfileId.ExecuteScalar());

                    // Fetch patient details from Profiles
                    OracleCommand getPatientDetails = new OracleCommand("SELECT FirstName, LastName, Email, PhoneNumber, Address FROM PROFILES WHERE ProfileID = :profileId", con);
                    getPatientDetails.Parameters.Add(":profileId", OracleDbType.Int32).Value = patientProfileId;
                    using (OracleDataReader reader = getPatientDetails.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Assign the details to textboxes here.
                            FirstName.Text = reader.GetString(0);
                            LastName.Text = reader.GetString(1);
                            Email.Text = reader.GetString(2);
                            PhoneNumber.Text = reader.GetString(3);
                            Address.Text = reader.GetString(4);

                        }
                    }

                    // Fetch employee ProfileID
                    int employeeProfileId;
                    OracleCommand getEmployeeProfileId = new OracleCommand("SELECT ProfileID FROM EMPLOYEES WHERE EmployeeID = :employeeId", con);
                    getEmployeeProfileId.Parameters.Add(":employeeId", OracleDbType.Int32).Value = employeeId;
                    employeeProfileId = Convert.ToInt32(getEmployeeProfileId.ExecuteScalar());

                    // Fetch employee name from Profiles
                    OracleCommand getEmployeeName = new OracleCommand("SELECT FirstName, LastName FROM PROFILES WHERE ProfileID = :profileId", con);
                    getEmployeeName.Parameters.Add(":profileId", OracleDbType.Int32).Value = employeeProfileId;
                    using (OracleDataReader reader = getEmployeeName.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Assign the doctor's name to the textbox here...
                            DocName.Text = reader.GetString(0) + " " + reader.GetString(1);
                        }
                    }

                    con.Close();
                }
            }
        }


        private void CustomizeDataGridView()
        {
            // Set the font for readability
            AppointmentsGrid.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            AppointmentsGrid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 10);

            // Purple and white color scheme
            AppointmentsGrid.BackgroundColor = Color.White;
            AppointmentsGrid.GridColor = Color.Lavender;
            AppointmentsGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.MediumPurple;
            AppointmentsGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set the RowHeaders to be invisible if not needed
            AppointmentsGrid.RowHeadersVisible = false;

            // Set grid lines for better separation of data
            AppointmentsGrid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            AppointmentsGrid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;

            // Adjust row height
            AppointmentsGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            AppointmentsGrid.RowTemplate.Height = 30; // Set this to a suitable height

            // Highlight the selected row
            AppointmentsGrid.DefaultCellStyle.SelectionBackColor = Color.DarkOrchid; // A professional purple color
            AppointmentsGrid.DefaultCellStyle.SelectionForeColor = Color.White;

            // Use alternating row style
            AppointmentsGrid.AlternatingRowsDefaultCellStyle.BackColor = Color.LavenderBlush; // A light purple tint
            AppointmentsGrid.AlternatingRowsDefaultCellStyle.ForeColor = Color.Black;

            // Auto-Size columns based on content
            AppointmentsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Make the grid read-only if you don't want users to edit it directly
            AppointmentsGrid.ReadOnly = true;

            // Enable row headers to select rows if needed
            AppointmentsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Reduce padding for a cleaner look
            AppointmentsGrid.DefaultCellStyle.Padding = new Padding(5);

            // Set the height for column headers
            AppointmentsGrid.ColumnHeadersHeight = 35;

            // Set wrap mode for text
            AppointmentsGrid.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            // Improve the look of the header cells
            AppointmentsGrid.EnableHeadersVisualStyles = false;
            AppointmentsGrid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Set the default cell style alignment
            AppointmentsGrid.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            // Set the border style for a flat look
            AppointmentsGrid.BorderStyle = BorderStyle.None;

            // Remove the last blank row
            AppointmentsGrid.AllowUserToAddRows = false;

            // Auto-Size columns based on content, including headers
            AppointmentsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            // Adjust row height
            AppointmentsGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            // Improve the look of the header cells
            AppointmentsGrid.EnableHeadersVisualStyles = false;
            AppointmentsGrid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            AppointmentsGrid.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True; // Ensure header text is wrapped properly

            // Set the height for column headers (optional, can be removed if auto-size is sufficient)
            AppointmentsGrid.ColumnHeadersHeight = 35;

        }


    }
}
