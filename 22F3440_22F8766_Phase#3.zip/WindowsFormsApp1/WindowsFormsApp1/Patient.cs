﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Oracle.ManagedDataAccess.Client;

namespace WindowsFormsApp1
{
    public partial class Patient : Form
    {
        private int PatId;
        public Patient(int userId)
        {
            InitializeComponent();
            LoadData(userId);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Patient_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        void LoadData(int userId)
        {
            using (OracleConnection con = new OracleConnection(@"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440"))
            {
                con.Open();

                // Fetch patient's profile information from the database using the userId
                OracleCommand getPatientProfile = con.CreateCommand();
                getPatientProfile.CommandText = @"SELECT Pr.FirstName,
                                               Pr.LastName,
                                               Pr.Email,
                                               Pr.PhoneNumber,
                                               Pr.DateOfBirth,
                                               Pa.PatientID
                                        FROM Profiles Pr
                                        INNER JOIN Patients Pa ON Pr.ProfileID = Pa.ProfileID
                                        INNER JOIN Users Us ON Pr.UserID = Us.UserID
                                        WHERE Us.UserID = :userId";
                getPatientProfile.CommandType = CommandType.Text;
                getPatientProfile.Parameters.Add(":userId", OracleDbType.Int32).Value = userId;

                // Execute the command
                OracleDataReader reader = getPatientProfile.ExecuteReader();

                // Check if data is returned
                if (reader.Read())
                {
                    // Fill the labels with retrieved data
                    patientName.Text = $"{reader["FirstName"]} {reader["LastName"]}";
                    emailLabel.Text = reader["Email"].ToString();
                    phoneLabel.Text = reader["PhoneNumber"].ToString();
                    dobLabel.Text = Convert.ToDateTime(reader["DateOfBirth"]).ToShortDateString();
                    patientId.Text = reader["PatientID"].ToString();
                    userIdLabel.Text = userId.ToString();
                }
                else
                {
                    
                    MessageBox.Show("Patient data not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                // Close the data reader and connection
                reader.Close();
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //close this form upon opening the form1.cs
            this.Hide();
            Form1 form1 = new Form1();
            form1.Closed += (s, args) => this.Close();
            form1.Show();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            //close this form upon opening the track appointment form with the same userId
            this.Hide();
            TrackAppointment trackAppointmentForm = new TrackAppointment(Convert.ToInt32(userIdLabel.Text));
            trackAppointmentForm.Closed += (s, args) => this.Close();
            trackAppointmentForm.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            //close this form upon opening the book appointment form with the same userId
            this.Hide();
            bookAppointment bookAppointmentForm = new bookAppointment(Convert.ToInt32(patientId.Text), Convert.ToInt32(userIdLabel.Text));
            bookAppointmentForm.Closed += (s, args) => this.Close();
            bookAppointmentForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //open the "appointmentHistory" form with the userId, and patientId as parameters and also close this form upon opening the appointmentHistory form
            this.Hide();
            appointmentHistory appointmentHistoryForm = new appointmentHistory( Convert.ToInt32(patientId.Text), Convert.ToInt32(userIdLabel.Text));
            appointmentHistoryForm.Closed += (s, args) => this.Close();
            appointmentHistoryForm.Show();

        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            addComplain addComplainForm = new addComplain(Convert.ToInt32(userIdLabel.Text));
                addComplainForm.Closed += (s, args) => this.Close();
            addComplainForm.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            //close this form upon opening the prescription.cs form with same userId
            this.Hide();
            //pass userid and patientid as well
            prescription prescriptionForm = new prescription(Convert.ToInt32(userIdLabel.Text), Convert.ToInt32(patientId.Text));
            prescriptionForm.Closed += (s, args) => this.Close();
            prescriptionForm.Show();


        }

        private void medicalHistoryButton_Click(object sender, EventArgs e)
        {
            //open CheckProfile.cs passing userID to it and close this form upon opening the CheckProfile form
            this.Hide();
            CheckProfiles checkProfileForm = new CheckProfiles(Convert.ToInt32(userIdLabel.Text));
            checkProfileForm.Closed += (s, args) => this.Close();
            checkProfileForm.Show();

        }
    }
}
