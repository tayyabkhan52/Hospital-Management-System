﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CheckProfiles : Form
    {
        int LocalUserId;
        public CheckProfiles(int UserId)
        {
            //save this UserId
            LocalUserId = UserId;
            InitializeComponent();
            string conStr = @"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440";
            OracleConnection con = new OracleConnection(conStr);
            con.Open();
            //show all profile of logged in user from profile table, firstname, lastname, email, phone, address and date of birth into the textboxes
            OracleCommand getProfile = con.CreateCommand();
            getProfile.CommandText = "SELECT FirstName, LastName, Email, PHONENUMBER, Address, DateOfBirth FROM PROFILES WHERE UserID = :userId";
            getProfile.CommandType = CommandType.Text;
            getProfile.Parameters.Add(":userId", OracleDbType.Int32).Value = LocalUserId;
            OracleDataReader reader = getProfile.ExecuteReader();
            if (reader.Read())
            {
                // Make sure to use the correct zero-based column indices
                FirstName.Text = reader.IsDBNull(0) ? "" : reader.GetString(0);
                LastName.Text = reader.IsDBNull(1) ? "" : reader.GetString(1);
                Email.Text = reader.IsDBNull(2) ? "" : reader.GetString(2);
                PhoneNumber.Text = reader.IsDBNull(3) ? "" : reader.GetString(3);
                Address.Text = reader.IsDBNull(4) ? "" : reader.GetString(4);
                if (!reader.IsDBNull(5)) // Assuming the DateOfBirth is at index 5
                {
                    DateTime dateValue = reader.GetDateTime(5);
                    //set the value from database which was (MM/dd/yyyy) format to the dateofbirth datetimepicker
                    DateofBirth.Value = dateValue;

                }
                else
                {
                    DateofBirth.Value = DateofBirth.MinDate; // Or some default value
                }
            }
            //now read the username and password from the users table
            OracleCommand getUser = con.CreateCommand();
            getUser.CommandText = "SELECT Username, Password FROM USERS WHERE UserID = :userId";
            getUser.CommandType = CommandType.Text;
            getUser.Parameters.Add(":userId", OracleDbType.Int32).Value = LocalUserId;
            OracleDataReader reader2 = getUser.ExecuteReader();
            if (reader2.Read())
            {
                Username.Text = reader2.GetString(0);
                UserPassword.Text = reader2.GetString(1);
            }


        

        }

        private void BackButtonProfile_Click(object sender, EventArgs e)
        {
            //check the role of the user and go back to the corresponding form
            string conStr = @"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440";
            OracleConnection con = new OracleConnection(conStr);
            con.Open();
            OracleCommand getRole = con.CreateCommand();
            getRole.CommandText = "SELECT RoleID FROM USERS WHERE UserID = :userId";
            getRole.CommandType = CommandType.Text;
            getRole.Parameters.Add(":userId", OracleDbType.Int32).Value = LocalUserId;
            int roleId = Convert.ToInt32(getRole.ExecuteScalar());
            if (roleId == 1) // Patient
            {
                
                this.Hide();
                Patient patientForm = new Patient(LocalUserId);
                patientForm.Closed += (s, args) => this.Close();
                patientForm.Show();
            }
            else if (roleId == 4 || roleId == 5 || roleId == 6) // Employee
            {
                this.Hide();
                Employee employeeForm = new Employee(LocalUserId); // Pass LocalUserId to Employee form
                employeeForm.Closed += (s, args) => this.Close();
                employeeForm.Show();
            }
            else if (roleId == 3) // Admin
            {
                this.Hide();
                //go back to admin form 
                Admin adminForm = new Admin(LocalUserId);
                adminForm.Closed += (s, args) => this.Close();
                adminForm.Show();
            }
            else
            {
                //open the customer support form
                this.Hide();
                CustomerSupport customerSupportForm = new CustomerSupport(LocalUserId);
                customerSupportForm.Closed += (s, args) => this.Close();
                customerSupportForm.Show();

            }
           
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            //update the user's profile information in the database using the LocalUserId from the  textboxes 
            string conStr = @"DATA SOURCE=localhost:1521/xe;PASSWORD=hello;USER ID=F223440";
            OracleConnection con = new OracleConnection(conStr);
            con.Open();
            OracleCommand updateProfile = con.CreateCommand();
            updateProfile.CommandText = "UPDATE PROFILES SET FirstName = :firstName, LastName = :lastName, Email = :email, PhoneNumber = :phoneNumber, Address = :address, DateOfBirth = :dateOfBirth WHERE UserID = :userId";
            updateProfile.CommandType = CommandType.Text;
            updateProfile.Parameters.Add(":firstName", OracleDbType.Varchar2).Value = FirstName.Text;
            updateProfile.Parameters.Add(":lastName", OracleDbType.Varchar2).Value = LastName.Text;
            updateProfile.Parameters.Add(":email", OracleDbType.Varchar2).Value = Email.Text;
            updateProfile.Parameters.Add(":phoneNumber", OracleDbType.Varchar2).Value = PhoneNumber.Text;
            updateProfile.Parameters.Add(":address", OracleDbType.Varchar2).Value = Address.Text;
            // For date of birth, format it to match your database format
            updateProfile.Parameters.Add(":dateOfBirth", OracleDbType.Date).Value = DateofBirth.Value;

            updateProfile.Parameters.Add(":userId", OracleDbType.Int32).Value = LocalUserId;
            updateProfile.ExecuteNonQuery();

            //update the user's username and password in the database using the LocalUserId from the  textboxes
            OracleCommand updateUser = con.CreateCommand();
            updateUser.CommandText = "UPDATE USERS SET Username = :username, Password = :password WHERE UserID = :userId";
            updateUser.CommandType = CommandType.Text;
            updateUser.Parameters.Add(":username", OracleDbType.Varchar2).Value = Username.Text;
            updateUser.Parameters.Add(":password", OracleDbType.Varchar2).Value = UserPassword.Text;
            updateUser.Parameters.Add(":userId", OracleDbType.Int32).Value = LocalUserId;
            updateUser.ExecuteNonQuery();
            MessageBox.Show("Profile Updated Successfully");
            InitializeComponent();


        }

        private void CheckProfiles_Load(object sender, EventArgs e)
        {

        }
    }

    
}
